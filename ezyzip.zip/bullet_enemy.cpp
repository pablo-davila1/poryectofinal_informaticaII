#include "bullet_enemy.h"

bullet_enemy::bullet_enemy()
{

}

void bullet_enemy::move()
{

}
